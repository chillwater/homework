#!/bin/bash
echo "this is a test from Chung-Chieh Kao"
